import streamlit as st
import tensorflow as tf
import numpy as np
from PIL import Image, ImageFilter
import os
from pathlib import Path

# Hide Streamlit top toolbar
st.markdown(
    """
    <style>
    header {visibility: hidden;}
    </style>
    """,
    unsafe_allow_html=True
)

# ----------------------------
# Page config
# ----------------------------
st.set_page_config(
    page_title="Traffic Sign Recognition",
    page_icon="🚦",
    layout="centered"
)

# ----------------------------
# Paths & config
# ----------------------------
MODEL_PATH = "traffic_sign_model.h5"
META_IMAGES_DIR = "Meta"
IMG_SIZE = (45, 45)

# ----------------------------
# Class mapping (GTSRB)
# ----------------------------
CLASSES = {
    0: 'Speed limit (20km/h)',
    1: 'Speed limit (30km/h)',
    2: 'Speed limit (50km/h)',
    3: 'Speed limit (60km/h)',
    4: 'Speed limit (70km/h)',
    5: 'Speed limit (80km/h)',
    6: 'End of speed limit (80km/h)',
    7: 'Speed limit (100km/h)',
    8: 'Speed limit (120km/h)',
    9: 'No passing',
    10: 'No passing veh over 3.5 tons',
    11: 'Right-of-way at intersection',
    12: 'Priority road',
    13: 'Yield',
    14: 'Stop',
    15: 'No vehicles',
    16: 'Veh > 3.5 tons prohibited',
    17: 'No entry',
    18: 'General caution',
    19: 'Dangerous curve left',
    20: 'Dangerous curve right',
    21: 'Double curve',
    22: 'Bumpy road',
    23: 'Slippery road',
    24: 'Road narrows on the right',
    25: 'Road work',
    26: 'Traffic signals',
    27: 'Pedestrians',
    28: 'Children crossing',
    29: 'Bicycles crossing',
    30: 'Beware of ice/snow',
    31: 'Wild animals crossing',
    32: 'End speed + passing limits',
    33: 'Turn right ahead',
    34: 'Turn left ahead',
    35: 'Ahead only',
    36: 'Go straight or right',
    37: 'Go straight or left',
    38: 'Keep right',
    39: 'Keep left',
    40: 'Roundabout mandatory',
    41: 'End of no passing',
    42: 'End no passing veh > 3.5 tons'
}

def label_name(class_id: int) -> str:
    return CLASSES.get(class_id, f"Class {class_id}")

# ----------------------------
# Load model
# ----------------------------
@st.cache_resource
def load_model():
    return tf.keras.models.load_model(MODEL_PATH)

# ----------------------------
# Preprocess (same as training)
# ----------------------------
def preprocess(img: Image.Image) -> np.ndarray:
    img = img.convert("RGB")
    img = img.filter(ImageFilter.EDGE_ENHANCE)
    img = img.resize(IMG_SIZE)
    arr = np.array(img, dtype=np.float32) / 255.0
    return np.expand_dims(arr, axis=0)

# ----------------------------
# Find example image in Meta folder
# ----------------------------
def find_meta_image_for_class(class_id: int) -> str | None:
    base = Path(META_IMAGES_DIR)

    # Meta/14.png
    for ext in ["png", "jpg", "jpeg"]:
        p = base / f"{class_id}.{ext}"
        if p.exists():
            return str(p)

    # Meta/14/<file>.png
    folder = base / str(class_id)
    if folder.exists() and folder.is_dir():
        for ext in ["png", "jpg", "jpeg"]:
            files = list(folder.glob(f"*.{ext}"))
            if files:
                return str(files[0])

    return None

# ----------------------------
# Header (centered)
# ----------------------------
st.markdown(
    """
    <h1 style="text-align:center;">🚦 Traffic Sign Recognition</h1>
    <p style="text-align:center; color:gray;">
        Upload an image of a traffic sign and click <b>Predict</b>.
    </p>
    """,
    unsafe_allow_html=True
)

st.divider()

# ----------------------------
# Checks & load
# ----------------------------
if not os.path.exists(MODEL_PATH):
    st.error("Model file `traffic_sign_model.h5` not found.")
    st.stop()

model = load_model()

# ----------------------------
# Upload
# ----------------------------
uploaded = st.file_uploader("Upload image", type=["png", "jpg", "jpeg"])

if uploaded:
    image = Image.open(uploaded)

    # ---- IMAGE (centered, no zoom) ----
    import base64
    from io import BytesIO

    buffer = BytesIO()
    image.save(buffer, format="PNG")
    img_base64 = base64.b64encode(buffer.getvalue()).decode()

    st.markdown(
        f"""
        <div style="text-align: center;">
            <img src="data:image/png;base64,{img_base64}"
                style="width:300px; pointer-events:none;" />
            <p style="color:gray; font-size:0.9rem;">Uploaded image</p>
        </div>
        """,
        unsafe_allow_html=True
    )

    st.divider()

    # ---- PREDICTION SECTION ----
    st.subheader("Prediction")

    predict = st.button("Predict")

    if predict:
        with st.spinner("Running prediction..."):
            x = preprocess(image)
            probs = model.predict(x, verbose=0)[0]

        pred_id = int(np.argmax(probs))
        confidence = float(probs[pred_id]) * 100
        sign_name = label_name(pred_id)

        st.success(f"**{sign_name}**")
        st.write(f"Confidence: **{confidence:.2f}%**")
        st.progress(min(int(confidence), 100))

        # ---- EXAMPLE + TOP-3 IN ONE ROW ----
        st.write("")
        spacer1, col1, spacer2, col2 = st.columns([0.2, 1, 0.2, 1])

        # LEFT: Reference sign
        with col1:
            st.markdown(
                """
                <p style="text-align:center;">
                    Reference traffic sign
                </p>
                """,
                unsafe_allow_html=True
            )

            meta_img = find_meta_image_for_class(pred_id)
            if meta_img:
                meta_image = Image.open(meta_img)
                buffer = BytesIO()
                meta_image.save(buffer, format="PNG")
                meta_base64 = base64.b64encode(buffer.getvalue()).decode()

                st.markdown(
                    f"""
                    <div style="text-align:center;">
                        <img src="data:image/png;base64,{meta_base64}"
                            style="width:100px; pointer-events:none; margin-top:6px;" />
                    </div>
                    """,
                    unsafe_allow_html=True
                )
            else:
                st.caption("No example image available.")

        # RIGHT: Top-3 predictions
        with col2:
            st.markdown("**Top-3 predictions**")
            top3 = np.argsort(probs)[::-1][:3]
            for i, idx in enumerate(top3, 1):
                st.write(
                    f"{i}. {label_name(int(idx))} — {probs[idx]*100:.2f}%"
                )
else:
    st.info("Upload an image to begin.")
