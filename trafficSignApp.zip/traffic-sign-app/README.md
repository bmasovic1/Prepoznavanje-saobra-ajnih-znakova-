# Running the Application

This project uses a trained deep learning model to recognize traffic signs and provides a simple web-based user interface built with Streamlit.

## Requirements
Before running the application, make sure you have the following installed on your system:
- Python 3.9 or newer
- pip (Python package manager)

## Setup and Run Instructions

1. Open a terminal and navigate to the project directory where `app.py` is located.

2. Install the required Python libraries by running: pip install streamlit tensorflow pillow numpy


## Start the Streamlit application by running:

streamlit run app.py

## Open the application in your web browser at: 

http://localhost:8501
